package com.example.bimo1795.response.login

data class Admin(
    val id:String,
    val email:String,
    val password:String,
    val nama:String
)
