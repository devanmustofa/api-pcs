package com.example.bimo1795.response.login

data class Data(
    val admin: Admin,
    val token:String
)
